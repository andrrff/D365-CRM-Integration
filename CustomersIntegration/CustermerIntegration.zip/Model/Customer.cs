﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomersIntegration.Model
{
    class Customer
    {
        class Account
        {
            public string Name { get; set; }
            public Guid AccountId { get; set; }
        }
    }
}
